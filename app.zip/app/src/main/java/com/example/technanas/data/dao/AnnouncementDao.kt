package com.example.technanas.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.technanas.data.model.Announcement
import kotlinx.coroutines.flow.Flow

@Dao
interface AnnouncementDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(announcements: List<Announcement>)

    @Query("SELECT * FROM announcements ORDER BY dateMillis DESC")
    fun getAllAnnouncements(): Flow<List<Announcement>>

    @Query("SELECT * FROM announcements WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): Announcement?

    @Query("SELECT COUNT(*) FROM announcements")
    suspend fun getCount(): Int
}
