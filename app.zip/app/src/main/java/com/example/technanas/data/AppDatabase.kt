package com.example.technanas.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.technanas.data.dao.AnnouncementDao
import com.example.technanas.data.dao.FAQDao
import com.example.technanas.data.dao.UserDao
import com.example.technanas.data.model.Announcement
import com.example.technanas.data.model.FAQ
import com.example.technanas.data.model.User

@Database(
    entities = [User::class, Announcement::class, FAQ::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun announcementDao(): AnnouncementDao
    abstract fun faqDao(): FAQDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "tech_nanas.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
