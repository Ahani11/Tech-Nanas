package com.example.technanas.ui

import android.content.Intent
import android.os.Bundle
import android.view.Menu          // <-- add this import
import android.view.MenuItem

import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.technanas.R
import com.example.technanas.TechNanasApp
import com.example.technanas.databinding.ActivityMainBinding
import com.example.technanas.ui.announcements.AnnouncementsFragment
import com.example.technanas.ui.faq.FAQChatFragment
import com.example.technanas.ui.links.LinksFragment
import com.example.technanas.ui.profile.ProfileFragment

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val app by lazy { application as TechNanasApp }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_announcements -> {
                    openFragment(AnnouncementsFragment())
                    true
                }
                R.id.nav_faq -> {
                    openFragment(FAQChatFragment())
                    true
                }
                R.id.nav_links -> {
                    openFragment(LinksFragment())
                    true
                }
                else -> false
            }
        }

        binding.bottomNav.selectedItemId = R.id.nav_announcements
    }



    // NEW: inflate the toolbar menu here
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }


    private fun openFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(binding.fragmentContainer.id, fragment)
            .commit()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_profile -> {
                openFragment(ProfileFragment())
                true
            }
            R.id.action_logout -> {
                showLogoutDialog()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showLogoutDialog() {
        AlertDialog.Builder(this)
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Yes") { _, _ ->
                app.sessionManager.logout()
                val intent = Intent(this, LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
