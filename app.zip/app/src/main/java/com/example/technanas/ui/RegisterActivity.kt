package com.example.technanas.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.technanas.TechNanasApp
import com.example.technanas.data.model.User
import com.example.technanas.data.repository.UserResult
import com.example.technanas.databinding.ActivityRegisterBinding
import com.example.technanas.util.ValidationUtils
import kotlinx.coroutines.launch

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private val app by lazy { application as TechNanasApp }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnRegister.setOnClickListener { attemptRegister() }
        binding.tvLoginLink.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    private fun attemptRegister() {
        val name = binding.etFullName.text.toString().trim()
        val ic = binding.etIcNumber.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString()
        val confirm = binding.etConfirmPassword.text.toString()

        if (name.isEmpty()) {
            binding.etFullName.error = "Required"
            return
        }
        if (ic.isEmpty()) {
            binding.etIcNumber.error = "Required"
            return
        }
        if (!ValidationUtils.isValidPhone(phone)) {
            binding.etPhone.error = "Invalid phone"
            return
        }
        if (!ValidationUtils.isValidEmail(email)) {
            binding.etEmail.error = "Invalid email"
            return
        }
        if (!ValidationUtils.isValidPassword(password)) {
            binding.etPassword.error = "At least 6 characters"
            return
        }
        if (password != confirm) {
            binding.etConfirmPassword.error = "Passwords do not match"
            return
        }

        val user = User(
            fullName = name,
            icNumber = ic,
            phone = phone,
            email = email,
            password = password
        )

        setLoading(true)

        lifecycleScope.launch {
            when (val result = app.userRepository.register(user)) {
                is UserResult.Success -> {
                    app.sessionManager.saveLoginSession(
                        result.user.id,
                        result.user.fullName,
                        result.user.email
                    )
                    Toast.makeText(this@RegisterActivity, "Welcome ${result.user.fullName}", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this@RegisterActivity, MainActivity::class.java))
                    finish()
                }
                is UserResult.Error -> {
                    Toast.makeText(this@RegisterActivity, result.message, Toast.LENGTH_SHORT).show()
                    setLoading(false)
                }
            }
        }
    }

    private fun setLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        binding.btnRegister.isEnabled = !isLoading
    }
}
