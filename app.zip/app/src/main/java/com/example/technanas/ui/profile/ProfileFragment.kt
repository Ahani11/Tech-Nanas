package com.example.technanas.ui.profile

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.technanas.TechNanasApp
import com.example.technanas.databinding.FragmentProfileBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    private val app by lazy { requireActivity().application as TechNanasApp }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val userId = app.sessionManager.getUserId()
        if (userId == null) {
            Toast.makeText(requireContext(), "No user logged in", Toast.LENGTH_SHORT).show()
            return
        }

        viewLifecycleOwner.lifecycleScope.launch {
            app.userRepository.getUserByIdFlow(userId).collectLatest { user ->
                if (user != null) {
                    binding.tvName.text = user.fullName
                    binding.tvEmail.text = user.email
                    binding.tvPhone.text = user.phone
                    binding.tvIc.text = user.icNumber
                    binding.tvFarmName.text = user.farmName ?: "-"
                    binding.tvFarmSize.text = user.farmSize ?: "-"
                    binding.tvFarmAddress.text = user.farmAddress ?: "-"
                    binding.tvState.text = user.state ?: "-"
                }
            }
        }

        binding.btnEditProfile.setOnClickListener {
            val intent = Intent(requireContext(), EditProfileActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
