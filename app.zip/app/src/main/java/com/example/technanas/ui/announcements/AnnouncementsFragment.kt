package com.example.technanas.ui.announcements

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.technanas.TechNanasApp
import com.example.technanas.data.model.Announcement
import com.example.technanas.data.model.AnnouncementType
import com.example.technanas.databinding.FragmentAnnouncementsBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class AnnouncementsFragment : Fragment() {

    private var _binding: FragmentAnnouncementsBinding? = null
    private val binding get() = _binding!!

    private val app by lazy { requireActivity().application as TechNanasApp }

    private lateinit var adapter: AnnouncementAdapter
    private var allAnnouncements: List<Announcement> = emptyList()
    private var selectedType: AnnouncementType? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAnnouncementsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = AnnouncementAdapter { announcement ->
            val intent = Intent(requireContext(), AnnouncementDetailActivity::class.java)
            intent.putExtra(AnnouncementDetailActivity.EXTRA_ANNOUNCEMENT_ID, announcement.id)
            startActivity(intent)
        }
        binding.recyclerViewAnnouncements.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerViewAnnouncements.adapter = adapter

        binding.chipAll.isChecked = true

        binding.chipAll.setOnClickListener {
            selectedType = null
            filterAnnouncements()
        }
        binding.chipPrice.setOnClickListener {
            selectedType = AnnouncementType.PRICE
            filterAnnouncements()
        }
        binding.chipPromo.setOnClickListener {
            selectedType = AnnouncementType.PROMOTION
            filterAnnouncements()
        }
        binding.chipEvent.setOnClickListener {
            selectedType = AnnouncementType.EVENT
            filterAnnouncements()
        }
        binding.chipTraining.setOnClickListener {
            selectedType = AnnouncementType.TRAINING
            filterAnnouncements()
        }

        viewLifecycleOwner.lifecycleScope.launch {
            app.announcementRepository.getAll().collectLatest { list ->
                allAnnouncements = list
                filterAnnouncements()
            }
        }
    }

    private fun filterAnnouncements() {
        val filtered = if (selectedType == null) {
            allAnnouncements
        } else {
            allAnnouncements.filter { it.type == selectedType }
        }
        adapter.submitList(filtered)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
