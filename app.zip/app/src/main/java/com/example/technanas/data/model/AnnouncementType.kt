package com.example.technanas.data.model

enum class AnnouncementType {
    PRICE,
    PROMOTION,
    EVENT,
    TRAINING,
    GENERAL,
    OTHER
}
