package com.example.technanas

import android.app.Application
import com.example.technanas.data.AppDatabase
import com.example.technanas.data.repository.AnnouncementRepository
import com.example.technanas.data.repository.FAQRepository
import com.example.technanas.data.repository.UserRepository
import com.example.technanas.session.SessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TechNanasApp : Application() {

    lateinit var sessionManager: SessionManager
        private set

    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }

    val userRepository: UserRepository by lazy { UserRepository(database.userDao()) }
    val announcementRepository: AnnouncementRepository by lazy { AnnouncementRepository(database.announcementDao()) }
    val faqRepository: FAQRepository by lazy { FAQRepository(database.faqDao()) }

    private val appScope = CoroutineScope(Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        sessionManager = SessionManager(this)

        appScope.launch {
            prepopulateDatabase()
        }
    }

    private suspend fun prepopulateDatabase() {
        val annDao = database.announcementDao()
        val faqDao = database.faqDao()

        if (annDao.getCount() == 0) {
            val now = System.currentTimeMillis()
            val sampleAnnouncements = com.example.technanas.data.sample.SampleData.sampleAnnouncements(now)
            annDao.insertAll(sampleAnnouncements)
        }

        if (faqDao.getCount() == 0) {
            val sampleFaqs = com.example.technanas.data.sample.SampleData.sampleFaqs()
            faqDao.insertAll(sampleFaqs)
        }
    }
}
