package com.example.technanas.data.repository

import com.example.technanas.data.dao.UserDao
import com.example.technanas.data.model.User
import kotlinx.coroutines.flow.Flow

sealed class UserResult {
    data class Success(val user: User) : UserResult()
    data class Error(val message: String) : UserResult()
}

class UserRepository(private val userDao: UserDao) {

    suspend fun register(user: User): UserResult {
        if (userDao.countByEmail(user.email) > 0) {
            return UserResult.Error("Email already registered.")
        }
        if (userDao.countByIc(user.icNumber) > 0) {
            return UserResult.Error("IC/Passport already registered.")
        }

        val id = userDao.insertUser(user)
        return UserResult.Success(user.copy(id = id))
    }

    suspend fun login(email: String, password: String): UserResult {
        val user = userDao.getUserByEmail(email) ?: return UserResult.Error("User not found.")
        if (user.password != password) {
            return UserResult.Error("Incorrect password.")
        }
        return UserResult.Success(user)
    }

    fun getUserByIdFlow(id: Long): Flow<User?> = userDao.getUserByIdFlow(id)

    suspend fun updateUser(user: User): UserResult {
        userDao.updateUser(user)
        return UserResult.Success(user)
    }
}
