package com.example.technanas.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.technanas.TechNanasApp
import com.example.technanas.data.repository.UserResult
import com.example.technanas.databinding.ActivityLoginBinding
import com.example.technanas.util.ValidationUtils
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val app by lazy { application as TechNanasApp }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener { attemptLogin() }
        binding.tvRegisterLink.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun attemptLogin() {
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString()

        if (!ValidationUtils.isValidEmail(email)) {
            binding.etEmail.error = "Invalid email"
            return
        }
        if (!ValidationUtils.isValidPassword(password)) {
            binding.etPassword.error = "Password too short"
            return
        }

        setLoading(true)

        lifecycleScope.launch {
            when (val result = app.userRepository.login(email, password)) {
                is UserResult.Success -> {
                    app.sessionManager.saveLoginSession(
                        result.user.id,
                        result.user.fullName,
                        result.user.email
                    )
                    Toast.makeText(this@LoginActivity, "Welcome ${result.user.fullName}", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                    finish()
                }
                is UserResult.Error -> {
                    Toast.makeText(this@LoginActivity, result.message, Toast.LENGTH_SHORT).show()
                    setLoading(false)
                }
            }
        }
    }

    private fun setLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        binding.btnLogin.isEnabled = !isLoading
    }
}
