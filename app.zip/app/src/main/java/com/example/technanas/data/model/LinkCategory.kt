package com.example.technanas.data.model

enum class LinkCategory {
    OFFICIAL,
    SOCIAL,
    GOVERNMENT,
    RESOURCE
}