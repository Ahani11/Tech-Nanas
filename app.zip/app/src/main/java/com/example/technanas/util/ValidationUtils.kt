package com.example.technanas.util

import android.util.Patterns

object ValidationUtils {

    fun isValidEmail(email: String): Boolean =
        email.isNotBlank() && Patterns.EMAIL_ADDRESS.matcher(email).matches()

    fun isValidPhone(phone: String): Boolean =
        phone.isNotBlank() && phone.length >= 8

    fun isValidPassword(password: String): Boolean =
        password.length >= 6
}
