package com.example.technanas.data.repository

import com.example.technanas.data.dao.AnnouncementDao
import com.example.technanas.data.model.Announcement
import kotlinx.coroutines.flow.Flow

class AnnouncementRepository(private val announcementDao: AnnouncementDao) {

    fun getAll(): Flow<List<Announcement>> = announcementDao.getAllAnnouncements()

    suspend fun getById(id: Long): Announcement? = announcementDao.getById(id)
}
