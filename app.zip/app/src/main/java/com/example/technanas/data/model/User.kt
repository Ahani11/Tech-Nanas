package com.example.technanas.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fullName: String,
    val icNumber: String,
    val phone: String,
    val email: String,
    val password: String,
    val farmName: String? = null,
    val farmSize: String? = null,
    val farmAddress: String? = null,
    val state: String? = null
)
