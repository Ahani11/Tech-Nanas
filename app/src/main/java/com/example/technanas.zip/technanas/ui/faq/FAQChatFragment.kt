package com.example.technanas.ui.faq

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.technanas.TechNanasApp
import com.example.technanas.data.model.ChatMessage
import com.example.technanas.databinding.FragmentFaqChatBinding
import kotlinx.coroutines.launch

class FAQChatFragment : Fragment() {

    private var _binding: FragmentFaqChatBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: ChatAdapter
    private val app by lazy { requireActivity().application as TechNanasApp }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFaqChatBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = ChatAdapter()
        binding.recyclerViewChat.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerViewChat.adapter = adapter

        viewLifecycleOwner.lifecycleScope.launch {
            val greeting = app.faqRepository.getGreetingResponse()
            adapter.addMessage(ChatMessage(text = greeting, isUser = false))
            scrollToBottom()
        }

        binding.btnSend.setOnClickListener {
            sendMessage()
        }
    }

    private fun sendMessage() {
        val text = binding.etMessage.text.toString().trim()
        if (text.isEmpty()) return

        adapter.addMessage(ChatMessage(text = text, isUser = true))
        binding.etMessage.text?.clear()
        scrollToBottom()

        viewLifecycleOwner.lifecycleScope.launch {
            val answer = app.faqRepository.getAnswerFor(text)
            adapter.addMessage(ChatMessage(text = answer, isUser = false))
            scrollToBottom()
        }
    }

    private fun scrollToBottom() {
        binding.recyclerViewChat.post {
            binding.recyclerViewChat.scrollToPosition(adapter.itemCount - 1)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
