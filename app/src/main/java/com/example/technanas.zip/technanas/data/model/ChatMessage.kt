package com.example.technanas.data.model

data class ChatMessage(
    val text: String,
    val isUser: Boolean
)
