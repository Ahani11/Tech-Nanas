package com.example.technanas.data.repository

import com.example.technanas.data.dao.FAQDao
import com.example.technanas.data.model.FAQ
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class FAQRepository(private val faqDao: FAQDao) {

    fun getAllFlow() = faqDao.getAll()

    suspend fun getGreetingResponse(): String = withContext(Dispatchers.Default) {
        "Hello! I am the TechNanas FAQ assistant. Ask me about account, prices, or pineapple farming. 🍍"
    }

    suspend fun getAnswerFor(question: String): String = withContext(Dispatchers.IO) {
        val q = question.lowercase()
        val faqs: List<FAQ> = faqDao.getAllOnce()
        if (faqs.isEmpty()) {
            return@withContext "Sorry, no FAQ data is available yet."
        }

        var bestFaq: FAQ? = null
        var bestScore = 0

        for (faq in faqs) {
            val combined = (faq.question + " " + faq.keywords).lowercase()
            var score = 0
            for (token in q.split(" ")) {
                val t = token.trim()
                if (t.length < 3) continue
                if (combined.contains(t)) score++
            }
            if (score > bestScore) {
                bestScore = score
                bestFaq = faq
            }
        }

        if (bestScore == 0 || bestFaq == null) {
            "Sorry, I am not sure. Please try asking in a simpler way or contact support."
        } else {
            bestFaq.answer
        }
    }
}
