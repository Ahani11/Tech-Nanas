package com.example.technanas.data.model

enum class FAQCategory {
    GENERAL,
    ACCOUNT,
    FARMING,
    PRICE,
    SUPPORT
}
